<?php

/**
 * Plugin Name: WooRec AI Recommendations
 * Plugin URI:  https://www.woorec.com
 * Description: Increase conversion rates with AI-driven product suggestions. Automatically personalize category sorting and sync data in real-time to deliver the perfect shopping experience.
 * Version:     1.0.0
 * Author:      WooRec
 * Author URI:  https://www.woorec.com
 * License:     GPL-2.0+
 * Text Domain: woorec
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * WC requires at least: 7.0
 */


if (!defined('ABSPATH')) {
    exit;
}

// ==========================================================================
// 1. Global Constants & Paths
// ==========================================================================
define('WOOREC_VERSION', '1.0.0');
define('WOOREC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WOOREC_PLUGIN_URL', plugin_dir_url(__FILE__));

// ==========================================================================
// 2. Load Core Modules
// ==========================================================================

// A. Constants
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-constants.php';

// B. Service Status & Helpers
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-service-status.php';

// C. API Communication Layer
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-api.php';

// [NEW] D. License & Status Sync (Must be after API)
// 这里的代码就是你刚才发给我的那个文件
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-license.php';

// E. Data Synchronization (Formatter & Logic)
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-data-sync.php';

// F. I2I Offline Sync (Pulling Recommendations)
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-i2i-sync.php';

// G. User Behavior Tracker
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-tracker.php';

// H. Frontend Recommendations (The_content & The_posts hooks)
require_once WOOREC_PLUGIN_DIR . 'includes/woorec-recommendations.php';

// I. Admin Settings
if (is_admin()) {
    require_once WOOREC_PLUGIN_DIR . 'includes/woorec-admin.php';
}

// ==========================================================================
// 3. Activation & Deactivation Hooks
// ==========================================================================

/**
 * Activation Hook
 * 1. Checks environment.
 * 2. Schedules Cron jobs.
 */
function woorec_activate_plugin()
{
    // Check for WooCommerce
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('WooRec requires WooCommerce to be installed and active.', 'woorec'));
    }

    // 1. Schedule Data Sync (Hourly)
    if (!wp_next_scheduled('woorec_hourly_sync_event')) {
        wp_schedule_event(time(), 'hourly', 'woorec_hourly_sync_event');
    }

    // 2. Schedule I2I Pull (Twice Daily)
    if (!wp_next_scheduled('woorec_twicedaily_i2i_event')) {
        wp_schedule_event(time(), 'twicedaily', 'woorec_twicedaily_i2i_event');
    }

    // 3. Schedule License & Config Sync (Every 30 Minutes)
    if (!wp_next_scheduled('woorec_scheduled_status_sync')) {
        wp_schedule_event(time(), 'woorec_30min', 'woorec_scheduled_status_sync');
    }

    // Initial License Check (Run immediately upon activation)
    // Because we loaded woorec-license.php above, this function is now available.
    if (function_exists('woorec_sync_user_status')) {
        woorec_sync_user_status();
    }
}
register_activation_hook(__FILE__, 'woorec_activate_plugin');

/**
 * Deactivation Hook
 * Clears scheduled cron jobs.
 */
function woorec_deactivate_plugin()
{
    wp_clear_scheduled_hook('woorec_hourly_sync_event');
    wp_clear_scheduled_hook('woorec_twicedaily_i2i_event');
    wp_clear_scheduled_hook('woorec_daily_license_event');
}
register_deactivation_hook(__FILE__, 'woorec_deactivate_plugin');

// ==========================================================================
// 4. Hook Cron Events
// ==========================================================================

add_action('woorec_hourly_sync_event', 'woorec_cron_sync_worker');
add_action('woorec_twicedaily_i2i_event', 'woorec_sync_i2i_batch');

// Note: 'woorec_daily_license_event' is already hooked inside woorec-license.php
// using add_action('woorec_daily_license_event', 'woorec_sync_user_status');
// so we don't need to add it again here.

// ==========================================================================
// 5. Localization
// ==========================================================================
add_action('plugins_loaded', 'woorec_load_textdomain');
function woorec_load_textdomain()
{
    load_plugin_textdomain('woorec', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

// ==========================================================================
// 6. Hook Replacements (Frontend)
// ==========================================================================

// Related Products
add_filter('woocommerce_related_products', function ($related_ids, $product_id, $args) {
    $limit = isset($args['posts_per_page']) ? $args['posts_per_page'] : 4;

    // Get AI recommendations
    $new_ids = woorec_get_related_products($product_id, $limit);

    if (!empty($new_ids)) {
        // ✅ TRACK HERE: We know exactly the source and the result
        woorec_trace_recommendation_exposure('related', $product_id, $new_ids);
        return $new_ids;
    }

    woorec_trace_recommendation_exposure('related', $product_id, $related_ids);
    return $related_ids;
}, 20, 3);

// Upsells
add_filter('woocommerce_product_get_upsell_ids', function ($upsell_ids, $product) {
    // Get AI recommendations
    $new_ids = woorec_get_upsells($product->get_id(), 5);

    if (!empty($new_ids)) {
        // ✅ TRACK HERE
        woorec_trace_recommendation_exposure('upsell', $product->get_id(), $new_ids);
        return $new_ids;
    }

    woorec_trace_recommendation_exposure('upsell', $product->get_id(), $upsell_ids);
    return $upsell_ids;
}, 20, 2);

// Cross-sells (Cart)
add_filter('woocommerce_cart_crosssell_ids', function ($cross_sell_ids, $cart) {
    // Get AI recommendations (Source ID is 0 because it's based on the whole cart, not one item)
    $new_ids = woorec_get_crosssells([], 5);

    if (!empty($new_ids)) {
        // ✅ TRACK HERE
        woorec_trace_recommendation_exposure('crosssell', 0, $new_ids);
        return $new_ids;
    }

    woorec_trace_recommendation_exposure('crosssell', 0, $cross_sell_ids);
    return $cross_sell_ids;
}, 20, 2);
