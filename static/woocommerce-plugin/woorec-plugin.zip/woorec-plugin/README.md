=== WooRec AI Recommendations ===
Contributors: yourname
Tags: woocommerce, recommendations, ai, related products, personalization
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Intelligent product recommendations for WooCommerce using advanced I2I algorithms and real-time data syncing.

== Description ==

WooRec replaces the standard WooCommerce related products with AI-driven recommendations. It supports real-time data synchronization and offline I2I (Item-to-Item) algorithm results to boost your conversion rates.

**Key Features:**

*   **Smart Sync:** Automatically syncs product data (incremental & full) to the AI engine.
*   **List Page Re-ranking:** Reorders products on Shop and Category pages based on user preferences.
*   **I2I Offline Support:** Periodically pulls recommendation data to local database for lightning-fast page loads.
*   **Customizable Scenes:** Supports Related, Upsell, Cross-sell, and List views.
*   **Performance First:** Uses non-blocking requests and optimized database queries.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/woorec-plugin` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to WooCommerce > Settings > WooRec to configure your API Host and Token.
4. The plugin will automatically start syncing your product catalog in the background.

== Frequently Asked Questions ==

= How often does the data sync? =
Product updates are synced instantly when you edit them. A background "Catch-up" job runs every hour to ensure data consistency.

= Does this slow down my site? =
No. The heavy lifting is done by the AI server. On the frontend, we use local database lookups (I2I) or asynchronous API calls with circuit breakers to ensure your site remains fast.

== Changelog ==

= 1.0.0 =
*   Initial release.
*   Added Item-to-Item (I2I) offline sync.
*   Added Category/List page re-ranking via `the_posts` filter.
*   Implemented "Time-Cursor" based incremental synchronization.
*   Added User Level configuration support.
