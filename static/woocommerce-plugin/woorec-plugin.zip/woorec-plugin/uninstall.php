<?php

/**
 * Fired when the plugin is deleted.
 *
 * This file is responsible for cleaning up ALL database entries created by the plugin.
 *
 * @package WooRec
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// ==========================================================================
// 1. Clean up Cron Jobs (Scheduled Tasks)
// ==========================================================================
// Explicitly clear known scheduled hooks to ensure they are removed from the 'cron' option.

$woorec_crons = [
    'woorec_hourly_sync_event',
    'woorec_twicedaily_i2i_event',
    'woorec_daily_license_event'
];

foreach ($woorec_crons as $cron_hook) {
    $timestamp = wp_next_scheduled($cron_hook);
    if ($timestamp) {
        wp_unschedule_event($timestamp, $cron_hook);
    }
    // Double check: Clear all occurrences just in case
    wp_clear_scheduled_hook($cron_hook);
}

// ==========================================================================
// 2. Delete All Plugin Options (Settings)
// ==========================================================================
// Uses SQL LIKE to delete everything starting with 'woorec_' or 'woorec_opt_'
// This is safer than listing them one by one, as it covers future settings automatically.

$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'woorec_%'"
);

// ==========================================================================
// 3. Delete All Post Meta (Recommendation Data)
// ==========================================================================
// Removes all data stored in products (like I2I results: _woorec_i2i_related_ids etc.)
// Pattern: '_woorec_%'

$wpdb->query(
    "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_woorec_%'"
);

// ==========================================================================
// 4. Delete Transients (Cached Data)
// ==========================================================================
// If you used any transients for caching API responses.

$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_woorec_%' OR option_name LIKE '_transient_timeout_woorec_%'"
);

// ==========================================================================
// 5. Optimization (Optional)
// ==========================================================================
// Since we deleted rows, we can optimize the tables, but usually, WordPress handles this.
// $wpdb->query("OPTIMIZE TABLE {$wpdb->options}");
// $wpdb->query("OPTIMIZE TABLE {$wpdb->postmeta}");
