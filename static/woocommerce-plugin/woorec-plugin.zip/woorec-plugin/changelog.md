# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-01-21

### Added
- **Core:** Initial plugin structure with Singleton-like architecture.
- **Sync:** Implemented `woorec-sync-scheduler.php` for robust "Time-Cursor" based synchronization (auto-detects full vs incremental).
- **I2I:** Added `woorec-sync-i2i.php` to pull batch recommendations from server and store in `postmeta`.
- **Scenes:** 
    - Added `WOOREC_SCENE_LIST` support.
    - Implemented `the_posts` filter hook to re-rank products on Shop and Category pages.
- **Config:** Added `WOOREC_OPT_USER_LEVEL` for service tier management.
- **Performance:** Added timeout and HTTP status checks for all API calls.

### Changed
- **API:** Standardized `_woorec_remote_request` with error handling.
- **Database:** Optimized meta updates using `array_map('intval')` for sanitization.
