<?php

/**
 * Admin Settings Page
 *
 * Handles the registration of the plugin settings menu, settings fields,
 * and renders the administration interface using Tailwind CSS.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

// ==========================================================================
// 1. Admin Menu Registration
// ==========================================================================

function woorec_add_admin_menu()
{
    add_menu_page(
        __('WooRec Settings', 'woorec'),
        __('WooRec Admin', 'woorec'),
        'manage_options',
        'woorec-settings',
        'woorec_settings_page_html',
        'dashicons-performance',
        50
    );
}
add_action('admin_menu', 'woorec_add_admin_menu');

// ==========================================================================
// 2. Settings Registration & Save Logic
// ==========================================================================

function woorec_register_settings()
{
    // 1. API Host
    register_setting('woorec_options_group', WOOREC_OPT_API_HOST, array(
        'sanitize_callback' => 'woorec_sanitize_host_url',
        'default'           => 'https://api.woorec.com/v1'
    ));

    // 2. API Key (Triggers Sync)
    register_setting('woorec_options_group', WOOREC_OPT_API_KEY, array(
        'sanitize_callback' => 'woorec_handle_api_save_logic'
    ));

    // 3. Recommendation Scenes
    register_setting('woorec_options_group', WOOREC_SCENE_RELATED, array('default' => '1'));
    register_setting('woorec_options_group', WOOREC_SCENE_UPSELL, array('default' => '1'));
    register_setting('woorec_options_group', WOOREC_SCENE_CROSSSELL, array('default' => '1'));
}
add_action('admin_init', 'woorec_register_settings');

/**
 * Helper: Sanitize Host URL
 */
function woorec_sanitize_host_url($url)
{
    if (empty($url)) {
        return 'https://api.woorec.com/v1';
    }
    return esc_url_raw($url);
}

/**
 * Core Logic: Sync User Status on API Key Save
 */
function woorec_handle_api_save_logic($new_api_key)
{
    // 1. Handle API Host Update immediately
    $current_host = get_option(WOOREC_OPT_API_HOST);
    if (isset($_POST[WOOREC_OPT_API_HOST])) {
        $raw_host = wp_unslash($_POST[WOOREC_OPT_API_HOST]);
        $current_host = woorec_sanitize_host_url($raw_host);
        update_option(WOOREC_OPT_API_HOST, $current_host);
    }

    // 2. Handle Empty Key (Reset Status)
    if (empty($new_api_key)) {
        update_option(WOOREC_OPT_USER_LEVEL, 'Free');
        update_option(WOOREC_OPT_USER_TTL, '0');

        // Update Status to False
        $status_data = get_option(WOOREC_SERVICE_STATUS_KEY, []);
        $status_data['status'] = false;
        update_option(WOOREC_SERVICE_STATUS_KEY, $status_data);

        return $new_api_key;
    }

    // 3. Trigger Synchronization & Check Status
    if (function_exists('woorec_sync_user_status')) {

        // A. Reset status temporarily before sync
        update_option(WOOREC_OPT_USER_TTL, '0');

        // B. Run the Sync
        $status = woorec_sync_user_status($new_api_key, $current_host);

        // C. Verification Logic
        // If woorec_sync_user_status succeeded, it should have updated this option.
        $is_connected = $status;

        // D. Update the Service Status Key
        $service_status = get_option(WOOREC_SERVICE_STATUS_KEY, []);
        $service_status['status'] = $is_connected;
        update_option(WOOREC_SERVICE_STATUS_KEY, $service_status);

        // E. Add UI Feedback (Settings Errors)
        if ($is_connected) {
            add_settings_error(
                'woorec_messages',
                'woorec_api_success',
                __('Connection successful! Your account has been verified.', 'woorec'),
                'success'
            );
        } else {
            add_settings_error(
                'woorec_messages',
                'woorec_api_error',
                __('Connection failed. Please check your API Key and Host URL.', 'woorec'),
                'error'
            );
        }
    }

    return sanitize_text_field($new_api_key);
}

// ==========================================================================
// 3. Admin UI Rendering
// ==========================================================================

function woorec_settings_page_html()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    // Retrieve Data
    $api_host   = get_option(WOOREC_OPT_API_HOST, 'https://api.woorec.engine/v2');
    $api_key    = get_option(WOOREC_OPT_API_KEY, '');
    $user_level = get_option(WOOREC_OPT_USER_LEVEL, 'Free');
    $raw_ttl    = get_option(WOOREC_OPT_USER_TTL, '0');

    // Retrieve Service Status
    $service_status = get_option(WOOREC_SERVICE_STATUS_KEY, []);
    $is_online      = isset($service_status['status']) && $service_status['status'] === true;

    // Retrieve Switch States
    $scene_related   = get_option(WOOREC_SCENE_RELATED, '1');
    $scene_upsell    = get_option(WOOREC_SCENE_UPSELL, '1');
    $scene_crosssell = get_option(WOOREC_SCENE_CROSSSELL, '1');

    // Logic: Calculate Subscription Days
    $days_remaining = 0;
    $progress_percent = 0;
    $ttl_display_text = "Unknown / Expired";

    if (is_numeric($raw_ttl) && $raw_ttl > time()) {
        $seconds_left = $raw_ttl - time();
        $days_remaining = ceil($seconds_left / 86400);
        $ttl_display_text = $days_remaining . " Days Remaining";
        $progress_percent = min(100, ($days_remaining / 30) * 100);
    } elseif (is_numeric($raw_ttl) && $raw_ttl <= time()) {
        $ttl_display_text = "Expired";
        $progress_percent = 0;
    } else {
        $ttl_display_text = "Unknown";
        $progress_percent = 100;
    }

?>

    <!-- Tailwind & Fonts -->
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />

    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#1791cf",
                        "background-light": "#f8fafc",
                        "background-dark": "#0f172a",
                        "success": "#22C55E",
                        "error": "#EF4444",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"]
                    },
                },
            },
            corePlugins: {
                preflight: false
            }
        }
    </script>

    <style>
        .woorec-admin-wrap {
            font-family: 'Inter', sans-serif;
        }

        .woorec-admin-wrap * {
            box-sizing: border-box;
        }

        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }

        .peer:checked~.peer-checked\:bg-primary {
            background-color: #1791cf;
        }

        .peer:checked~.peer-checked\:after\:translate-x-full {
            --tw-translate-x: 100%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
        }

        .peer:checked~.peer-checked\:after\:border-white::after {
            border-color: #ffffff;
        }

        #wpcontent {
            padding-left: 0;
        }

        /* Message Styles */
        .notice {
            display: none !important;
        }

        /* Hide default WP notices to use our custom styled ones if desired, or keep them */
    </style>

    <div class="woorec-admin-wrap bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen">

        <form action="options.php" method="post">
            <?php
            settings_fields('woorec_options_group');
            do_settings_sections('woorec_options_group');
            ?>

            <div class="max-w-4xl mx-auto px-6 py-16">

                <!-- Header -->
                <div class="text-center mb-12">
                    <div class="inline-flex items-center justify-center size-16 bg-primary rounded-2xl text-white mb-6 shadow-xl shadow-primary/20">
                        <span class="material-symbols-outlined text-4xl">settings_suggest</span>
                    </div>
                    <h1 class="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">WooRec Settings</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-lg max-w-xl mx-auto">Configure your engine connection and manage product recommendation features.</p>

                    <!-- Display Feedback Messages Here -->
                    <div class="mt-6">
                        <?php settings_errors('woorec_messages'); ?>
                    </div>

                    <!-- System Status Badge -->
                    <?php if (!empty($api_key)) : ?>
                        <div class="mt-6 flex justify-center">
                            <?php if ($is_online) : ?>
                                <span class="flex items-center gap-1.5 px-4 py-2 bg-success/10 text-success text-xs font-bold rounded-full border border-success/20">
                                    <span class="material-symbols-outlined text-base fill-1">check_circle</span>
                                    System Online & Verified
                                </span>
                            <?php else : ?>
                                <span class="flex items-center gap-1.5 px-4 py-2 bg-error/10 text-error text-xs font-bold rounded-full border border-error/20">
                                    <span class="material-symbols-outlined text-base fill-1">error</span>
                                    Connection Failed
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="bg-white dark:bg-slate-900 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-slate-200 dark:border-slate-800 overflow-hidden">
                    <div class="p-8 lg:p-12 space-y-12">

                        <!-- SECTION 1: API Configuration -->
                        <section>
                            <div class="flex items-center gap-3 mb-8">
                                <div class="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                                    <span class="material-symbols-outlined">hub</span>
                                </div>
                                <h2 class="text-xl font-bold text-slate-900 dark:text-white">API Configuration</h2>
                            </div>

                            <div class="grid md:grid-cols-2 gap-8">
                                <!-- Inputs -->
                                <div class="space-y-6">
                                    <!-- API Host -->
                                    <div class="flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <label class="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">API Host URL</label>
                                            <div class="group relative">
                                                <span class="material-symbols-outlined text-slate-400 text-lg cursor-help">info</span>
                                                <div class="absolute bottom-full right-0 mb-2 w-64 p-3 bg-slate-900 text-white text-[11px] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 leading-relaxed shadow-xl">
                                                    Your unique API endpoint. Found in your dashboard under 'Integration Settings'.
                                                </div>
                                            </div>
                                        </div>
                                        <input
                                            name="<?php echo esc_attr(WOOREC_OPT_API_HOST); ?>"
                                            class="w-full px-4 py-3 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-medium text-slate-900 dark:text-white"
                                            type="text"
                                            value="<?php echo esc_attr($api_host); ?>" />
                                    </div>

                                    <!-- API Key -->
                                    <div class="flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <label class="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">API Key</label>
                                        </div>
                                        <div class="relative">
                                            <input
                                                id="woorec-api-key"
                                                name="<?php echo esc_attr(WOOREC_OPT_API_KEY); ?>"
                                                class="w-full px-4 py-3 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-mono text-slate-900 dark:text-white"
                                                type="password"
                                                value="<?php echo esc_attr($api_key); ?>" />
                                            <button type="button" id="woorec-toggle-key" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer">
                                                <span class="material-symbols-outlined text-xl">visibility</span>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Connect Button (Submits Form) -->
                                    <div class="pt-2">
                                        <button type="submit" name="submit" class="w-full md:w-auto px-8 py-3.5 bg-primary hover:bg-primary/90 text-white rounded-xl font-bold transition-all shadow-lg shadow-primary/20 flex items-center justify-center gap-2 cursor-pointer border-0">
                                            <span class="material-symbols-outlined text-xl">sync_alt</span>
                                            Connect & Verify
                                        </button>
                                    </div>
                                </div>

                                <!-- Status Box -->
                                <div class="bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 p-6">
                                    <h3 class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-6">Account Status</h3>
                                    <div class="space-y-6">
                                        <!-- Plan -->
                                        <div class="flex items-start gap-4">
                                            <div class="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                                                <span class="material-symbols-outlined">workspace_premium</span>
                                            </div>
                                            <div>
                                                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Plan Level</p>
                                                <p class="text-base font-bold text-slate-900 dark:text-white"><?php echo esc_html(strtoupper($user_level)); ?></p>
                                            </div>
                                        </div>
                                        <!-- Subscription / TTL -->
                                        <div class="flex items-start gap-4">
                                            <div class="size-10 rounded-lg bg-orange-100 dark:bg-orange-500/10 text-orange-600 flex items-center justify-center shrink-0">
                                                <span class="material-symbols-outlined">event_repeat</span>
                                            </div>
                                            <div class="flex-1">
                                                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Subscription</p>
                                                <p class="text-base font-bold text-slate-900 dark:text-white"><?php echo esc_html($ttl_display_text); ?></p>

                                                <!-- Progress Bar -->
                                                <div class="mt-2 w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                                    <div class="h-full bg-orange-500 rounded-full" style="width: <?php echo intval($progress_percent); ?>%"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mt-8">
                                        <a class="w-full flex items-center justify-center gap-2 px-4 py-2.5 border-2 border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-sm font-bold rounded-xl transition-all group no-underline" href="#" target="_blank">
                                            Manage Account
                                            <span class="material-symbols-outlined text-lg group-hover:translate-x-1 transition-transform">open_in_new</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <div class="h-px bg-slate-100 dark:bg-slate-800 w-full"></div>

                        <!-- SECTION 2: Recommendation Settings -->
                        <section>
                            <div class="flex items-center gap-3 mb-8">
                                <div class="size-10 rounded-lg bg-success/10 text-success flex items-center justify-center">
                                    <span class="material-symbols-outlined">auto_awesome</span>
                                </div>
                                <h2 class="text-xl font-bold text-slate-900 dark:text-white">Recommendation Settings</h2>
                            </div>

                            <div class="grid sm:grid-cols-3 gap-4">

                                <!-- 1. Related Products -->
                                <div class="p-6 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col justify-between gap-6 transition-all hover:border-primary/20">
                                    <div class="space-y-1">
                                        <p class="font-bold text-slate-900 dark:text-white">Related Products</p>
                                        <p class="text-xs text-slate-500">Show similar items on single product pages.</p>
                                    </div>
                                    <div class="flex items-center">
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" name="<?php echo WOOREC_SCENE_RELATED; ?>" value="1" class="sr-only peer" <?php checked('1', $scene_related); ?> />
                                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary rounded-full"></div>
                                        </label>
                                    </div>
                                </div>

                                <!-- 2. Upsell Products -->
                                <div class="p-6 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col justify-between gap-6 transition-all hover:border-primary/20">
                                    <div class="space-y-1">
                                        <p class="font-bold text-slate-900 dark:text-white">Upsell Products</p>
                                        <p class="text-xs text-slate-500">Recommend higher-end alternatives to visitors.</p>
                                    </div>
                                    <div class="flex items-center">
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" name="<?php echo WOOREC_SCENE_UPSELL; ?>" value="1" class="sr-only peer" <?php checked('1', $scene_upsell); ?> />
                                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary rounded-full"></div>
                                        </label>
                                    </div>
                                </div>

                                <!-- 3. Cross-sell Products -->
                                <div class="p-6 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col justify-between gap-6 transition-all hover:border-primary/20">
                                    <div class="space-y-1">
                                        <p class="font-bold text-slate-900 dark:text-white">Cross-sell Products</p>
                                        <p class="text-xs text-slate-500">Suggest complementary items during checkout.</p>
                                    </div>
                                    <div class="flex items-center">
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" name="<?php echo WOOREC_SCENE_CROSSSELL; ?>" value="1" class="sr-only peer" <?php checked('1', $scene_crosssell); ?> />
                                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary rounded-full"></div>
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </section>

                    </div>

                    <!-- Footer / Save Actions -->
                    <div class="bg-slate-50 dark:bg-slate-800/50 px-8 py-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="flex items-center gap-2 text-slate-400 text-sm italic">
                            <span class="material-symbols-outlined text-sm">security</span>
                            All configuration changes are applied instantly to your store.
                        </div>
                        <div class="flex items-center gap-4 w-full sm:w-auto">
                            <!-- Main Save Button -->
                            <button type="submit" name="submit" class="flex-1 sm:flex-none px-10 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-sm font-bold shadow-lg transition-transform active:scale-95 border-0 cursor-pointer">
                                Save All Settings
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Footer Links -->
                <div class="mt-12 flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
                    <a class="text-slate-400 hover:text-primary text-sm font-medium flex items-center gap-1.5 transition-colors no-underline" target="_blank"
                        rel="noopener noreferrer" href="https://www.woorec.com/docs/getting-started">
                        <span class="material-symbols-outlined text-base">description</span>
                        Documentation
                    </a>
                    <a class="text-slate-400 hover:text-primary text-sm font-medium flex items-center gap-1.5 transition-colors no-underline" target="_blank"
                        rel="noopener noreferrer" href="https://www.woorec.com/support">
                        <span class="material-symbols-outlined text-base">support_agent</span>
                        Contact Support
                    </a>
                    <a class="text-slate-400 hover:text-primary text-sm font-medium flex items-center gap-1.5 transition-colors no-underline" target="_blank"
                        rel="noopener noreferrer" href="https://www.woorec.com/privacy-policy">
                        <span class="material-symbols-outlined text-base">policy</span>
                        Privacy Policy
                    </a>
                </div>

            </div>
        </form>
    </div>

    <!-- JavaScript for Password Toggle -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleBtn = document.getElementById('woorec-toggle-key');
            const keyInput = document.getElementById('woorec-api-key');

            if (toggleBtn && keyInput) {
                toggleBtn.addEventListener('click', function() {
                    const isPassword = keyInput.type === 'password';
                    keyInput.type = isPassword ? 'text' : 'password';

                    const icon = toggleBtn.querySelector('span');
                    if (icon) {
                        icon.textContent = isPassword ? 'visibility_off' : 'visibility';
                    }
                });
            }
        });
    </script>
<?php
}
?>