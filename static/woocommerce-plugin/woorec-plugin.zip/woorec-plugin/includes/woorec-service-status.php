<?php

/**
 * Service Availability & Circuit Breaker
 *
 * Manages the connection status to the remote AI engine.
 * Implements a "Circuit Breaker" pattern to stop sending requests
 * if the service is detected as down, preventing site performance issues.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Checks if the external service is available.
 *
 * Determines if we should attempt to contact the API or if the
 * circuit breaker is currently open (blocking requests).
 *
 * @return bool True if service is available (or half-open), False if blocked.
 */
function woorec_check_service_status()
{
    $service_status = get_option(WOOREC_SERVICE_STATUS_KEY);

    // 1. No status record means the service is healthy (Closed Circuit)
    if (empty($service_status) || !is_array($service_status)) {
        return true;
    }

    // 2. Explicitly marked as active/healthy
    if (!empty($service_status['status']) && $service_status['status'] === true) {
        return true;
    }

    // 3. Service is marked as Down (Open Circuit). Check Cooldown.
    // We use time() (UTC) for consistent internal timing.
    $now = time();
    $retry_after = $service_status['ts'] + $service_status['interval'];

    if ($now <= $retry_after) {
        // Still in cooldown period. Block request.
        return false;
    }

    // 4. Cooldown passed (Half-Open State).
    // We remove the lock to allow ONE attempt.
    // If it succeeds, the API handler will call reset_status().
    // If it fails, record_failure() will start a new count.
    delete_option(WOOREC_SERVICE_STATUS_KEY);

    return true;
}

/**
 * Records a connection failure and manages the circuit breaker state.
 *
 * Increments the failure count. If the threshold is reached,
 * it "trips" the circuit and sets a cooldown interval.
 *
 * @return void
 */
function woorec_service_record_failure()
{
    $service_status = get_option(WOOREC_SERVICE_STATUS_KEY);

    // Initialize defaults if not exists
    if (empty($service_status) || !is_array($service_status)) {
        $service_status = [
            'count'    => 0,
            'status'   => true, // True = Healthy
            'interval' => 3600, // Initial cooldown: 1 hour
            'ts'       => time()
        ];
    }

    // Increment failure counter
    $service_status['count']++;
    $service_status['ts'] = time();

    // Check if we reached the threshold (e.g., 8 failures)
    if ($service_status['count'] >= WOOREC_HAP_MAX_RETRY_NUM) {
        // Trip the circuit
        $service_status['status'] = false;

        // Exponential backoff (or linear add), maxing at 24 hours
        // Here we add 1 hour per trip level, capped at 24 hours.
        $new_interval = $service_status['interval'] + 3600;
        $service_status['interval'] = min($new_interval, 24 * 3600);

        error_log(sprintf(
            '[WooRec] Circuit Breaker TRIPPED. Failures: %d. Pausing for %d seconds.',
            $service_status['count'],
            $service_status['interval']
        ));
    }

    update_option(WOOREC_SERVICE_STATUS_KEY, $service_status);
}

/**
 * Resets the service status to healthy.
 *
 * Should be called after a successful API response to clear
 * any previous failure counts.
 *
 * @return void
 */
function woorec_service_reset_status()
{
    // Only delete if it exists to save DB writes
    if (get_option(WOOREC_SERVICE_STATUS_KEY) !== false) {
        delete_option(WOOREC_SERVICE_STATUS_KEY);
    }
}
