<?php

/**
 * License & Status Synchronization
 *
 * Handles the synchronization of user subscription status (Level & TTL)
 * from the remote server.
 * 
 * NOTE: Scheduled tasks (Cron) have been removed. This now runs only on-demand
 * (e.g., when saving settings).
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Syncs the user's license status from the server.
 *
 * This function is triggered manually during settings save.
 *
 * @param string|null $override_key  Optional. If provided, uses this key instead of DB value.
 * @param string|null $override_host Optional. If provided, uses this host instead of DB value.
 * @return void
 */
function woorec_sync_user_status($override_key = null, $override_host = null)
{
    // 1. Determine Credentials
    // Use overrides if provided (during save), otherwise fetch from database.
    $api_key  = $override_key  !== null ? $override_key  : get_option(WOOREC_OPT_API_KEY);
    $api_host = $override_host !== null ? $override_host : get_option(WOOREC_OPT_API_HOST);

    // 2. Configuration Check
    // If credentials are missing, exit silently.
    if (empty($api_key) || empty($api_host)) {
        return false;
    }

    // 3. Construct URL & Arguments Manually
    // We construct the request here to ensure the NEW key is used in the headers.
    $url = rtrim($api_host, '/') . WOOREC_API_PATH_STATUS;

    $args = [
        'timeout' => 5.0,
        'headers' => [
            'Content-Type'  => 'application/json',
            // FIX: Added 'Bearer ' prefix for standard API authentication if needed, 
            // currently keeping your original logic:
            'Authorization' => $api_key,
            'X-WP-Url'      => get_home_url(),
        ],
    ];

    // 4. Send Request
    $response = wp_remote_post($url, $args);

    // 5. Validate Transport
    if (is_wp_error($response)) {
        error_log('[WooRec] License Sync Error: ' . $response->get_error_message());
        return false;
    }

    // 6. Validate HTTP Code
    $response_code = wp_remote_retrieve_response_code($response);
    if ($response_code !== 200) {
        error_log('[WooRec] License Sync HTTP Error. Code: ' . $response_code);
        return false;
    }

    // 7. Parse Response
    $body = wp_remote_retrieve_body($response);
    $result = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('[WooRec] License Sync JSON Error: ' . json_last_error_msg());
        return false;
    }

    // 8. Update Options
    if (!empty($result['data'])) {
        $data = $result['data'];

        // --- A. Sync Level ---
        if (isset($data['level'])) {
            $sanitized_level = sanitize_text_field($data['level']);
            update_option(WOOREC_OPT_USER_LEVEL, $sanitized_level);
        } else {
            return false;
        }

        // --- B. Sync TTL ---
        if (isset($data['ttl'])) {
            $clean_ttl = intval($data['ttl']);
            update_option(WOOREC_OPT_USER_TTL, $clean_ttl);
        } else {
            return false;
        }
        return true;
    }
    return false;
}
