<?php

/**
 * Recommendation Logic Controller
 *
 * Handles the decision making between Real-time API (Pro) and Local DB (Standard)
 * based on user subscription level, TTL, and granular scene configurations.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

// ==========================================================================
// 1. Core Decision Logic (Service Mode)
// ==========================================================================

/**
 * Determines the current operation mode based on Level, TTL, and Scene Settings.
 *
 * @param string $scene The scene context ('related', 'upsell', 'crosssell', 'list').
 *                      If empty, only performs global Level/TTL checks.
 * 
 * @return string 'api' (Pro), 'db' (Standard), or 'off' (Expired/Disabled).
 */
function woorec_get_service_mode($scene = '')
{
    // 1. Global TTL Check (Priority #1)
    // If the service is expired, everything is off regardless of settings.
    $ttl = (int)get_option(WOOREC_OPT_USER_TTL, 0);
    $now = time(); // UTC

    if ($ttl <= $now) {
        return 'off'; // Service expired
    }

    // 2. Scene-Specific Toggle Check (Priority #2)
    // If a specific scene is passed, check if the user has enabled it in settings.
    if (!empty($scene)) {
        // Option names: woorec_enable_related, woorec_enable_upsell, etc.
        // Default is 'yes' (enabled) if option doesn't exist.
        $option_name = 'woorec_scene_' . $scene;
        $is_enabled  = get_option($option_name, '0');

        if ($is_enabled !== '1') {
            return 'off'; // User explicitly disabled this specific scene.
        }
    }

    // 3. Level/Tier Check (Priority #3)
    // Determine if we should use API or DB based on subscription level.
    $level = strtolower(get_option(WOOREC_OPT_USER_LEVEL, 'standard'));
    $high_tier_keywords = ['pro', 'advanced', 'premium', 'enterprise', 'api'];

    if (in_array($level, $high_tier_keywords)) {
        return 'api'; // High Tier -> Real-time API.
    }

    return 'db'; // Standard Tier -> Local Database.
}

// ==========================================================================
// 2. Related Products (Scene: Related)
// ==========================================================================

/**
 * Retrieves related products based on service mode.
 */
function woorec_get_related_products($product_id, $limit = 5)
{
    // [Change] Pass 'related' context
    $mode = woorec_get_service_mode('related');

    if ($mode === 'api') {
        return woorec_get_related_products_api($product_id, $limit);
    } elseif ($mode === 'db') {
        return woorec_get_related_products_db($product_id);
    }

    // If 'off', return empty array so WooCommerce uses its default logic.
    return [];
}

/**
 * API implementation for Related Products.
 */
function woorec_get_related_products_api($product_id, $limit)
{
    $user_info = woorec_get_user_info();
    $payload = array_merge($user_info, [
        'scene'   => WOOREC_SCENE_RELATED,
        'product' => $product_id,
        'limit'   => $limit,
        'ts'      => time()
    ]);
    return woorec_recommend_call($payload);
}

/**
 * Database implementation for Related Products.
 */
function woorec_get_related_products_db($product_id)
{
    $ids = get_post_meta($product_id, WOOREC_META_RELATED, true);
    return (!empty($ids) && is_array($ids)) ? array_map('intval', $ids) : [];
}

// ==========================================================================
// 3. Upsells (Scene: Upsell)
// ==========================================================================

/**
 * Retrieves upsell products based on service mode.
 */
function woorec_get_upsells($product_id, $limit = 5)
{
    // [Change] Pass 'upsell' context
    $mode = woorec_get_service_mode('upsell');

    if ($mode === 'api') {
        return woorec_get_upsells_api($product_id, $limit);
    } elseif ($mode === 'db') {
        return woorec_get_upsells_db($product_id);
    }

    return [];
}

/**
 * API implementation for Upsells.
 */
function woorec_get_upsells_api($product_id, $limit)
{
    $user_info = woorec_get_user_info();
    $payload = array_merge($user_info, [
        'scene'   => WOOREC_SCENE_UPSELL,
        'product' => $product_id,
        'limit'   => $limit,
        'ts'      => time()
    ]);
    return woorec_recommend_call($payload);
}

/**
 * Database implementation for Upsells.
 */
function woorec_get_upsells_db($product_id)
{
    $ids = get_post_meta($product_id, WOOREC_META_UPSELL, true);
    return (!empty($ids) && is_array($ids)) ? array_map('intval', $ids) : [];
}

// ==========================================================================
// 4. Cross-sells (Scene: Cross-sell / Cart)
// ==========================================================================

/**
 * Retrieves cross-sell products based on service mode.
 */
function woorec_get_crosssells($cart_item_ids = [], $limit = 5)
{
    // [Change] Pass 'crosssell' context
    $mode = woorec_get_service_mode('crosssell');

    if ($mode === 'api') {
        return woorec_get_crosssells_api($cart_item_ids, $limit);
    } elseif ($mode === 'db') {
        return woorec_get_crosssells_db($cart_item_ids);
    }

    return [];
}

/**
 * API implementation for Cross-sells.
 */
function woorec_get_crosssells_api($cart_item_ids, $limit)
{
    if (empty($cart_item_ids) && function_exists('WC') && WC()->cart) {
        $cart_contents = WC()->cart->get_cart();
        if (!empty($cart_contents)) {
            $cart_item_ids = array_column($cart_contents, 'product_id');
        }
    }

    if (empty($cart_item_ids)) {
        return [];
    }

    $user_info = woorec_get_user_info();
    $payload = array_merge($user_info, [
        'scene'    => WOOREC_SCENE_CROSSSELL,
        'products' => array_values($cart_item_ids),
        'limit'    => $limit,
        'ts'       => time()
    ]);

    return woorec_recommend_call($payload);
}

/**
 * Database implementation for Cross-sells.
 */
function woorec_get_crosssells_db($cart_item_ids)
{
    if (empty($cart_item_ids) && function_exists('WC') && WC()->cart) {
        $cart_contents = WC()->cart->get_cart();
        if (!empty($cart_contents)) {
            $cart_item_ids = array_column($cart_contents, 'product_id');
        }
    }

    if (empty($cart_item_ids)) {
        return [];
    }

    $recommended_ids = [];
    foreach ($cart_item_ids as $p_id) {
        $ids = get_post_meta($p_id, WOOREC_META_CROSSSELL, true);
        if (!empty($ids) && is_array($ids)) {
            $recommended_ids = array_merge($recommended_ids, $ids);
        }
    }

    $recommended_ids = array_unique($recommended_ids);
    $final_ids = array_diff($recommended_ids, $cart_item_ids);

    return array_map('intval', $final_ids);
}

// ==========================================================================
// 5. List / Category Page Recommendations (API Only)
// ==========================================================================

function woorec_inject_list_recommendations($posts, $query)
{
    if (is_admin() || !$query->is_main_query()) return $posts;

    // [Update] Allow execution on Shop, Category, OR Search pages
    if (!is_shop() && !is_product_category() && !is_search()) return $posts;

    // [Change] Pass 'list' context. 
    // If 'off' (disabled in settings) OR 'db' (standard tier), we return original posts.
    if (woorec_get_service_mode('list') !== 'api') {
        return $posts;
    }

    remove_filter('the_posts', 'woorec_inject_list_recommendations', 10);

    try {
        $category_id = 0;
        if (is_product_category()) {
            $obj = get_queried_object();
            if ($obj instanceof WP_Term) $category_id = $obj->term_id;
        }

        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
        $limit = get_query_var('posts_per_page') ? get_query_var('posts_per_page') : 12;

        // --- NEW: Capture Query Conditions (Search & Filters) ---
        $conditions = [];

        // 1. Search Query
        if (get_search_query()) {
            $conditions['search_query'] = get_search_query();
        }

        // 2. Sorting (orderby)
        if (isset($_GET['orderby'])) {
            $conditions['orderby'] = sanitize_text_field($_GET['orderby']);
        }

        // 3. Price Filtering (min_price / max_price)
        if (isset($_GET['min_price'])) {
            $conditions['min_price'] = sanitize_text_field($_GET['min_price']);
        }
        if (isset($_GET['max_price'])) {
            $conditions['max_price'] = sanitize_text_field($_GET['max_price']);
        }

        // 4. Attribute Filtering (filter_color, query_type_, etc.)
        foreach ($_GET as $key => $value) {
            if (strpos($key, 'filter_') === 0 || strpos($key, 'query_type_') === 0) {
                $conditions[$key] = sanitize_text_field($value);
            }
        }
        // --------------------------------------------------------

        $user_info = woorec_get_user_info();

        $payload = array_merge($user_info, [
            'scene'       => WOOREC_SCENE_LIST,
            'category_id' => $category_id,
            'page'        => $paged,
            'limit'       => $limit,
            'conditions'  => $conditions, // Pass the captured conditions
            'ts'          => time()
        ]);

        $rec_data = woorec_recommend_call($payload);

        if (!empty($rec_data) && is_array($rec_data)) {
            $post_ids = array_map('intval', $rec_data);
            if (!empty($post_ids)) {
                $args = [
                    'post_type'      => 'product',
                    'post__in'       => $post_ids,
                    'orderby'        => 'post__in',
                    'posts_per_page' => -1,
                    'suppress_filters' => true,
                ];
                $rec_query = new WP_Query($args);
                if (!empty($rec_query->posts)) {
                    $posts = $rec_query->posts;
                }
            }
        }
    } catch (Exception $e) {
        error_log('[WooRec] List injection error: ' . $e->getMessage());
    }

    add_filter('the_posts', 'woorec_inject_list_recommendations', 10, 2);
    return $posts;
}

add_filter('the_posts', 'woorec_inject_list_recommendations', 10, 2);
