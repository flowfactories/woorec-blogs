<?php

/**
 * I2I (Item-to-Item) Synchronization
 *
 * Handles the retrieval of offline recommendation results separated by scenes
 * (Related, Upsell, Cross-sell) and stores them in distinct meta fields.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Syncs I2I recommendation data from the server.
 *
 * The API is expected to return data grouped by scene keys:
 * 'related', 'upsell', 'crosssell'.
 *
 * @return void
 */
function woorec_sync_i2i_batch()
{
    // 1. Send Request to Server
    $response = _woorec_remote_request(WOOREC_API_PATH_I2I, [], true, 5.0);

    // 2. Error Handling
    if (is_wp_error($response)) {
        error_log('[WooRec] I2I Sync Transport Error: ' . $response->get_error_message());
        return;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    if ($response_code !== 200) {
        error_log('[WooRec] I2I Sync HTTP Error. Code: ' . $response_code);
        return;
    }

    // 3. Parse JSON Body
    $body   = wp_remote_retrieve_body($response);
    $result = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('[WooRec] I2I Sync JSON Parse Error: ' . json_last_error_msg());
        return;
    }

    if (empty($result['data']) || !is_array($result['data'])) {
        return;
    }

    // 4. Define Scene Mapping
    // Map the API JSON keys to our WordPress Meta Keys
    // {
    //   "data": {
    //     "related":   { "101": [201, 202], "102": [...] },
    //     "upsell":    { "101": [301, 302] },
    //     "crosssell": { "101": [401, 402] }
    //   }
    // }

    $scene_map = [
        'related'   => WOOREC_META_RELATED,
        'upsell'    => WOOREC_META_UPSELL,
        'crosssell' => WOOREC_META_CROSSSELL
    ];

    $total_updates = 0;

    // 5. Iterate Scenes and Update
    foreach ($scene_map as $api_key => $meta_key) {

        // Check if the API returned data for this specific scene
        if (!isset($result['data'][$api_key]) || !is_array($result['data'][$api_key])) {
            continue;
        }

        $scene_data = $result['data'][$api_key];
        $scene_count = 0;

        foreach ($scene_data as $product_id => $recommended_ids) {
            if (is_numeric($product_id)) {
                // Pass the specific meta key for this scene
                woorec_update_product_i2i_meta((int)$product_id, $recommended_ids, $meta_key);
                $scene_count++;
            }
        }

        $total_updates += $scene_count;

        if ($scene_count > 0) {
            error_log(sprintf('[WooRec] Synced %s: %d products updated.', $api_key, $scene_count));
        }
    }

    if ($total_updates > 0) {
        error_log(sprintf('[WooRec] Total I2I Sync Complete. %d updates across all scenes.', $total_updates));
    }
}

/**
 * Updates a specific I2I meta field for a single product.
 *
 * @param int    $product_id      The ID of the product to update.
 * @param array  $recommended_ids An array of recommended product IDs.
 * @param string $meta_key        The specific meta key to update (Related/Upsell/Crosssell).
 * @return void
 */
function woorec_update_product_i2i_meta($product_id, $recommended_ids, $meta_key)
{
    // 1. Basic Validation
    if (empty($product_id) || !is_array($recommended_ids) || empty($meta_key)) {
        return;
    }

    // 2. Sanitize Data
    // Ensure all IDs are integers.
    $clean_ids = array_map('intval', $recommended_ids);
    $clean_ids = array_filter($clean_ids); // Remove 0s
    $clean_ids = array_values($clean_ids); // Re-index

    // 3. Update Database
    update_post_meta($product_id, $meta_key, $clean_ids);
}