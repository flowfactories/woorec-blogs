<?php

/**
 * API Communication Layer
 *
 * Handles all HTTP requests to the remote AI engine, including
 * configuration retrieval, user context collection, and request dispatching.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Retrieves the API configuration from database options.
 *
 * @return array|null Returns ['url' => string, 'token' => string] or null if not configured.
 */
function woorec_get_api_config()
{
    $api_host = get_option(WOOREC_OPT_API_HOST);
    $api_key  = get_option(WOOREC_OPT_API_KEY);

    if (empty($api_host) || empty($api_key)) {
        return null;
    }

    // Ensure URL doesn't have a trailing slash for consistency
    return [
        'url'   => rtrim($api_host, '/'),
        'token' => $api_key
    ];
}

/**
 * Collects current user context information.
 *
 * Gathers User ID, hashed email (for privacy), and WooCommerce Session ID.
 *
 * @return array User context data.
 */
function woorec_get_user_info()
{
    $data = [
        'user_id'       => 0,
        'user_email_md5' => '',
        'cookie_id'     => ''
    ];

    // 1. Logged-in User Data
    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        $data['user_id'] = $user->ID;
        // Hash PII (Personally Identifiable Information) for privacy/GDPR compliance
        $data['user_email_md5'] = md5(strtolower(trim($user->user_email)));
    }

    // 2. WooCommerce Session ID (Guest Tracking)
    if (function_exists('WC') && isset(WC()->session) && is_object(WC()->session)) {
        // get_customer_id() returns the user ID or a unique session string for guests
        $data['cookie_id'] = WC()->session->get_customer_id();
    }

    return $data;
}

/**
 * Internal helper to send HTTP requests to the AI Engine.
 *
 * Handles GZIP compression, authentication headers, and error handling.
 *
 * @param string $endpoint  The API endpoint (e.g., '/rec').
 * @param array  $data      The payload data.
 * @param bool   $blocking  Whether to wait for the response (true) or fire-and-forget (false).
 * @param float  $timeout   Request timeout in seconds.
 * @return array|WP_Error   The response array or WP_Error on failure.
 */
function _woorec_remote_request($endpoint, $data, $blocking = true, $timeout = 1.0)
{
    // 1. Circuit Breaker Check
    // If the service is marked as 'down', stop sending requests to prevent site lag.
    if (function_exists('woorec_check_service_status') && !woorec_check_service_status()) {
        return new WP_Error('service_unavailable', 'Service temporarily unavailable due to previous failures.');
    }

    // 2. Get Config
    $config = woorec_get_api_config();
    if (!$config) {
        return new WP_Error('missing_config', 'API Configuration missing.');
    }

    // 3. Compress Payload
    // Using simple json_encode to prevent type coercion issues (removed JSON_NUMERIC_CHECK)
    $json_data = json_encode($data);
    if ($json_data === false) {
        return new WP_Error('json_encode_failed', 'Failed to encode data to JSON.');
    }

    $compressed_data = gzencode($json_data);
    if ($compressed_data === false) {
        return new WP_Error('gzip_failed', 'GZIP compression failed.');
    }

    // 4. Send Request
    $args = [
        'method'    => 'POST',
        'body'      => $compressed_data,
        'timeout'   => $timeout,
        'blocking'  => $blocking,
        'headers'   => [
            'Content-Type'     => 'application/json',
            'Content-Encoding' => 'gzip',
            'Authorization'    => $config['token'],
            'X-WP-Url'         => get_home_url(),
        ],
        // Security: Default to true, but allow developers to bypass via filter if needed.
        'sslverify' => apply_filters('woorec_ssl_verify', true),
    ];

    $response = wp_remote_post($config['url'] . $endpoint, $args);

    return $response;
}

/**
 * Calls the real-time recommendation API.
 *
 * This is a blocking call used for generating recommendations on the fly.
 *
 * @param array $data The context payload (user info, current product, etc.).
 * @return array      List of recommended product IDs.
 */
function woorec_recommend_call($data)
{
    // Very short timeout (0.5s) to ensure frontend performance
    $response = _woorec_remote_request(WOOREC_API_PATH_REC, $data, true, 0.5);

    // 1. Transport Error
    if (is_wp_error($response)) {
        if (function_exists('woorec_service_record_failure')) {
            woorec_service_record_failure();
        }
        return [];
    }

    // 2. HTTP Status Error
    if (wp_remote_retrieve_response_code($response) !== 200) {
        if (function_exists('woorec_service_record_failure')) {
            woorec_service_record_failure();
        }
        return [];
    }

    // 3. Parse JSON
    $body = wp_remote_retrieve_body($response);
    $ret  = json_decode($body, true);

    if (json_last_error() === JSON_ERROR_NONE && isset($ret['data'])) {
        // Success: Reset the circuit breaker
        if (function_exists('woorec_service_reset_status')) {
            woorec_service_reset_status();
        }
        return $ret['data'];
    }

    return [];
}

/**
 * Sends user behavior tracking data.
 *
 * Used for 'view', 'click', 'purchase' events. 
 * Non-blocking (Fire-and-forget) to avoid impacting user experience.
 *
 * @param array $data Tracking payload.
 * @return void
 */
function woorec_trace_send($data)
{
    // Ultra-short timeout (0.1s) just to fire the request
    _woorec_remote_request(WOOREC_API_PATH_TRACE, $data, false, 0.1);
}

/**
 * Sends incremental data synchronization updates.
 *
 * Used when a product is updated or created.
 *
 * @param array $data Product data payload.
 * @return void
 */
function woorec_inc_sync($data)
{
    // 1.0s timeout is sufficient for async sync
    _woorec_remote_request(WOOREC_API_PATH_INC_SYNC, $data, false, 1.0);
}
