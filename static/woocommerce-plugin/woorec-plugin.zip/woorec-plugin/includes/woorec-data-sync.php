<?php

/**
 * Data Synchronization Worker
 *
 * Implements an incremental synchronization mechanism based on modification timestamps.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Sync Worker
 *
 * STRATEGY CHANGE: PROCESS ISOLATION
 * Instead of looping internally, this function processes ONE batch and then exits.
 * If more data is needed, it schedules itself to run again immediately in a NEW process.
 * This guarantees 100% memory cleanup between batches.
 *
 * @return void
 */
function woorec_cron_sync_worker()
{
    // 1. Configuration Check
    $api_key = get_option(WOOREC_OPT_API_KEY);
    $api_host = get_option(WOOREC_OPT_API_HOST);

    if (empty($api_key) || empty($api_host)) {
        return;
    }

    // 2. Prevent Overlapping Runs (Locking)
    // If a job is already running, don't start another one to prevent race conditions.
    $lock_key = 'woorec_sync_lock';
    if (get_transient($lock_key)) {
        // Check if the lock is stale (older than 2 minutes). If so, break it.
        // Otherwise, exit.
        return;
    }
    set_transient($lock_key, time(), 120); // Lock for 2 minutes

    // 3. Memory Optimization Settings
    // Suspend cache addition to prevent WP Object Cache from exploding
    wp_suspend_cache_addition(true);
    wp_defer_term_counting(true);
    wp_defer_comment_counting(true);

    // Try to increase memory limit dynamically just for this process
    @ini_set('memory_limit', '1024M');

    // 4. Prepare Query
    $last_sync_ts = (int) get_option(WOOREC_OPT_LAST_SYNC_TIME, 0);
    $query_after_ts = max(0, $last_sync_ts - WOOREC_SYNC_BUFFER);
    $date_query_str = gmdate('Y-m-d H:i:s', $query_after_ts);

    // BATCH SIZE: Keep it small. If 1GB crashes, your products are likely very heavy (lots of variations?).
    // Let's try 50. If it still crashes, lower to 20.
    $batch_size = 50;

    $args = [
        'post_type'      => 'product',
        'post_status'    => ['publish', 'private'],
        'posts_per_page' => $batch_size,
        'fields'         => 'ids',
        'orderby'        => 'modified',
        'order'          => 'ASC',
        'date_query'     => [
            [
                'column'    => 'post_modified_gmt',
                'after'     => $date_query_str,
                'inclusive' => false,
            ]
        ],
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'cache_results'          => false,
    ];

    $query = new WP_Query($args);
    $found_posts = count($query->posts);

    // 5. Process Batch
    if ($found_posts > 0) {
        $batch_data = [];
        $batch_max_ts = 0;

        foreach ($query->posts as $p_id) {
            $product = wc_get_product($p_id);
            if (!$product) continue;

            $p_data = woorec_prepare_product_data($product);
            if ($p_data) {
                $batch_data[] = $p_data;
            }

            $modified_gmt = $product->get_date_modified() ? $product->get_date_modified()->getTimestamp() : 0;
            if ($modified_gmt > $batch_max_ts) {
                $batch_max_ts = $modified_gmt;
            }

            // Cleanup immediately
            unset($product);
            unset($p_data);
        }

        // Send Data
        if (!empty($batch_data)) {
            woorec_inc_sync(['data' => $batch_data, 'ts' => time()]);

            error_log(sprintf(
                '[WooRec] Sync Job: Processed %d items. Cursor moved to %s (UTC)',
                count($batch_data),
                gmdate('Y-m-d H:i:s', $batch_max_ts)
            ));
        }

        // Update Cursor
        if ($batch_max_ts > $last_sync_ts) {
            update_option(WOOREC_OPT_LAST_SYNC_TIME, $batch_max_ts);
        }

        // Cleanup Memory
        unset($batch_data);
        unset($query);

        // Force Garbage Collection
        if (function_exists('gc_collect_cycles')) {
            gc_collect_cycles();
        }

        // 6. CHAIN REACTION: Schedule Next Run Immediately
        // If we found a full batch, there is likely more data.
        // Schedule a single event to run in 2 seconds (Async Loop).
        // This creates a fresh PHP process for the next batch.
        if ($found_posts >= $batch_size) {
            wp_schedule_single_event(time() + 2, 'woorec_scheduled_status_sync');
            // Note: Make sure 'woorec_scheduled_status_sync' is the hook name associated with this function!
            // If the hook name is 'woorec_cron_sync_worker', change it above.
        } else {
            // We are caught up.
            // Move cursor to NOW to be safe for next scheduled run.
            update_option(WOOREC_OPT_LAST_SYNC_TIME, time());
        }
    } else {
        // No posts found, we are synced.
        update_option(WOOREC_OPT_LAST_SYNC_TIME, time());
    }

    // Release Lock
    delete_transient($lock_key);

    // Restore Settings
    wp_suspend_cache_addition(false);
    wp_defer_term_counting(false);
    wp_defer_comment_counting(false);
}

// Hook - Ensure this matches what you use in your main plugin file
// add_action('woorec_scheduled_status_sync', 'woorec_cron_sync_worker');

/**
 * Transforms a WooCommerce product into a standardized array structure.
 * (Keep your existing function here)
 */
function woorec_prepare_product_data($product)
{
    if (is_numeric($product)) {
        $product = wc_get_product($product);
    }

    if (!$product || !is_a($product, 'WC_Product')) {
        return null;
    }

    $data = [
        'id'          => $product->get_id(),
        'title'       => $product->get_name(),
        'permalink'   => $product->get_permalink(),
        'status'      => $product->get_status(),
        'type'        => $product->get_type(),
        'sku'         => $product->get_sku(),
        'created_at'  => $product->get_date_created() ? $product->get_date_created()->getTimestamp() : 0,
        'updated_at'  => $product->get_date_modified() ? $product->get_date_modified()->getTimestamp() : 0,
    ];

    $data['price']         = (float) $product->get_price();
    $data['regular_price'] = (float) $product->get_regular_price();
    $data['sale_price']    = (float) $product->get_sale_price();
    $data['on_sale']       = $product->is_on_sale();
    $data['stock_status']  = $product->get_stock_status();
    $data['stock_qty']     = $product->get_stock_quantity();

    $image_id = $product->get_image_id();
    $data['image_url'] = $image_id ? wp_get_attachment_url($image_id) : '';

    $cats = [];
    $term_ids = $product->get_category_ids();
    if (!empty($term_ids)) {
        foreach ($term_ids as $term_id) {
            $term = get_term($term_id, 'product_cat');
            if ($term && !is_wp_error($term)) {
                $cats[] = ['id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug];
            }
        }
    }
    $data['categories'] = $cats;

    $tags = [];
    $tag_ids = $product->get_tag_ids();
    if (!empty($tag_ids)) {
        foreach ($tag_ids as $tag_id) {
            $tag = get_term($tag_id, 'product_tag');
            if ($tag && !is_wp_error($tag)) {
                $tags[] = $tag->name;
            }
        }
    }
    $data['tags'] = $tags;

    $desc = $product->get_short_description() ?: $product->get_description();
    $data['description'] = wp_strip_all_tags($desc);

    return $data;
}
