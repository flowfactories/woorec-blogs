<?php

/**
 * User Behavior Tracker & Recommendation Injector
 *
 * 1. Captures standard user actions (View, Add-to-Cart, Purchase).
 * 2. Injects AI recommendations into WooCommerce loops (via Filters).
 * 3. HYBRID TRACKING:
 *    - Backend Filters: Track Related/Upsells/Cross-sells (High Accuracy).
 *    - Frontend Hooks: Track Shop/Category/Home lists (General Coverage).
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

// ==========================================================================
// 1. View Item (Product Detail Page)
// ==========================================================================

function woorec_trace_product_view()
{
    if (is_admin() || !is_singular('product')) {
        return;
    }

    $product_id = get_queried_object_id();
    $product = wc_get_product($product_id);

    if (!$product) {
        return;
    }

    $data = woorec_get_user_info();
    $data['action']  = 'view_item';
    $data['product'] = $product->get_id();
    $data['ts']      = time();

    // Metadata
    $data['name']      = $product->get_name();
    $data['sku']       = $product->get_sku();
    $data['price']     = (float) $product->get_price();
    $data['inventory'] = $product->get_stock_quantity();

    woorec_trace_send($data);
}
add_action('template_redirect', 'woorec_trace_product_view');


// ==========================================================================
// 2. Add to Cart (With Source Detection)
// ==========================================================================

function woorec_trace_add_to_cart($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data)
{
    if (is_admin() && !defined('DOING_AJAX')) return;

    $product = wc_get_product($product_id);
    if (!$product) return;

    $data = woorec_get_user_info();
    $data['action']    = 'add_to_cart';
    $data['product']   = $product->get_id();
    $data['variation'] = $variation_id ? $variation_id : 0;
    $data['quantity']  = (int) $quantity;
    $data['ts']        = time();

    // Source Detection
    $is_ajax = defined('DOING_AJAX') && DOING_AJAX;
    $referer = wp_get_referer();

    $data['source_type'] = $is_ajax ? 'ajax_direct' : 'page_submit';

    if ($referer) {
        if (strpos($referer, '/product/') !== false) {
            $data['context'] = 'product_detail';
        } elseif (strpos($referer, '/cart/') !== false || strpos($referer, '/checkout/') !== false) {
            $data['context'] = 'cart_upsell';
        } else {
            $data['context'] = 'list_page';
        }
    }

    $data['name']      = $product->get_name();
    $data['sku']       = $product->get_sku();
    $data['price']     = (float) $product->get_price();

    woorec_trace_send($data);
}
add_action('woocommerce_add_to_cart', 'woorec_trace_add_to_cart', 10, 6);


// ==========================================================================
// 3. Remove from Cart
// ==========================================================================

function woorec_trace_remove_from_cart($cart_item_key, $cart)
{
    $item = null;
    if (isset($cart->removed_cart_contents[$cart_item_key])) {
        $item = $cart->removed_cart_contents[$cart_item_key];
    } elseif (isset($cart->cart_contents[$cart_item_key])) {
        $item = $cart->cart_contents[$cart_item_key];
    }

    if (!$item) return;

    $data = woorec_get_user_info();
    $data['action']     = 'remove_from_cart';
    $data['product']    = isset($item['product_id']) ? $item['product_id'] : 0;
    $data['variation']  = isset($item['variation_id']) ? $item['variation_id'] : 0;
    $data['ts']         = time();

    woorec_trace_send($data);
}
add_action('woocommerce_cart_item_removed', 'woorec_trace_remove_from_cart', 10, 2);


// ==========================================================================
// 4. Purchase (Payment Complete)
// ==========================================================================

function woorec_trace_payment_success($order_id)
{
    if (!$order_id) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    $data = woorec_get_user_info();
    $data['action']   = 'purchase';
    $data['order_id'] = $order_id;
    $data['currency'] = $order->get_currency();
    $data['total']    = (float) $order->get_total();
    $data['ts']       = time();

    $items = $order->get_items();
    $pay_items = [];

    foreach ($items as $item) {
        $product = $item->get_product();

        $info = [
            'product_id'   => $item->get_product_id(),
            'variation_id' => $item->get_variation_id(),
            'quantity'     => $item->get_quantity(),
            'line_total'   => (float) $item->get_total(),
        ];

        if ($product) {
            $info['name']  = $product->get_name();
            $info['sku']   = $product->get_sku();
            $info['price'] = (float) $product->get_price();
        } else {
            $info['name']  = $item->get_name();
        }

        $pay_items[] = $info;
    }

    $data['items'] = $pay_items;

    woorec_trace_send($data);
}
add_action('woocommerce_payment_complete', 'woorec_trace_payment_success');


// ==========================================================================
// 5. Frontend List Tracking (Shop / Category / Home)
// ==========================================================================

global $woorec_list_buffer;
$woorec_list_buffer = [];

/**
 * Modified: Sends list batch with Search, Filter, and Pagination conditions
 */
function _woorec_send_list_batch($raw_ids)
{
    if (empty($raw_ids)) return;
    $product_ids = array_values(array_map('intval', array_unique($raw_ids)));

    $data = woorec_get_user_info();

    // Default context
    $data['context'] = 'list';

    // Initialize conditions array
    $conditions = [];

    // 1. Detect Page Context (Search vs Category vs Shop)
    if (is_search()) {
        $data['context'] = 'search_results';
        $conditions['search_query'] = get_search_query(); // Capture search keywords
    } elseif (is_product_category() || is_product_tag() || is_tax('product_brand')) {
        $data['context'] = 'category_list';
        $obj = get_queried_object();
        if ($obj) {
            $conditions['taxonomy']  = $obj->taxonomy; // e.g., product_cat
            $conditions['term_id']   = $obj->term_id;
            $conditions['term_name'] = $obj->name;
        }
    } elseif (is_shop()) {
        $data['context'] = 'shop_main';
    }

    // 2. Capture URL Filter Parameters (Sorting, Price, Attributes)

    // Sorting
    if (isset($_GET['orderby'])) {
        $conditions['orderby'] = sanitize_text_field($_GET['orderby']);
    }

    // Price Filtering
    if (isset($_GET['min_price'])) {
        $conditions['min_price'] = sanitize_text_field($_GET['min_price']);
    }
    if (isset($_GET['max_price'])) {
        $conditions['max_price'] = sanitize_text_field($_GET['max_price']);
    }

    // Attribute Filtering
    foreach ($_GET as $key => $value) {
        if (strpos($key, 'filter_') === 0 || strpos($key, 'query_type_') === 0) {
            $conditions[$key] = sanitize_text_field($value);
        }
    }

    // 3. Capture Pagination (New)
    // get_query_var('paged') returns 0 or empty for the first page, so we default to 1.
    $paged = get_query_var('paged');
    $conditions['page'] = $paged ? (int) $paged : 1;

    // Attach conditions to payload if they exist
    if (!empty($conditions)) {
        $data['conditions'] = $conditions;
    }

    $data['action']    = 'view_item_list';
    $data['count']     = count($product_ids);
    $data['products']  = $product_ids;
    $data['ts']        = time();

    woorec_trace_send($data);
}


/**
 * Tracks items in standard loops (Shop, Category).
 * SKIPS if we are on a Product Detail page (because Filters handle those).
 */
function woorec_collect_list_impression()
{
    global $product, $woorec_list_buffer;

    // 1. Safety Checks
    if (!$product instanceof WC_Product) return;

    // 2. CRITICAL: Avoid Double Tracking
    // If we are on a single product page, the items shown are "Related" or "Upsells".
    // We let the Backend Filters (Section 6) handle those for better accuracy.
    if (is_singular('product')) {
        return;
    }

    // 3. Add to Buffer
    $woorec_list_buffer[] = $product->get_id();

    // 4. Threshold Flush
    if (count($woorec_list_buffer) >= 12) {
        _woorec_send_list_batch($woorec_list_buffer);
        $woorec_list_buffer = [];
    }
}

// Hook into multiple places to ensure we catch the list items
add_action('woocommerce_shop_loop_item_title', 'woorec_collect_list_impression', 99);
add_action('woocommerce_before_shop_loop_item_title', 'woorec_collect_list_impression', 99);

/**
 * Flush remaining list items at footer
 */
add_action('wp_footer', function () {
    global $woorec_list_buffer;
    if (!empty($woorec_list_buffer)) {
        _woorec_send_list_batch($woorec_list_buffer);
        $woorec_list_buffer = [];
    }
}, 20);


// ==========================================================================
// 6. Backend Recommendation Tracking (Filters)
// ==========================================================================

/**
 * Helper: Sends recommendation exposure data accurately.
 */
function woorec_trace_recommendation_exposure($context, $source_id, $ids)
{
    if (empty($ids)) return;

    $product_ids = array_values(array_map('intval', array_unique($ids)));

    $data = woorec_get_user_info();
    $data['action']    = 'view_item_list';
    $data['context']   = $context;
    $data['source_id'] = $source_id;
    $data['count']     = count($product_ids);
    $data['products']  = $product_ids;
    $data['ts']        = time();

    if (function_exists('woorec_trace_send')) {
        woorec_trace_send($data);
    }
}
