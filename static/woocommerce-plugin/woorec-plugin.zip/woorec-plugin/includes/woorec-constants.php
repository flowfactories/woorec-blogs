<?php

/**
 * Plugin Constants
 *
 * Defines all global constants used throughout the WooRec plugin.
 * This includes database keys, API endpoints, and synchronization settings.
 *
 * @package WooRec
 */

if (!defined('ABSPATH')) {
    exit;
}

// ==========================================================================
// 1. Settings & Option Keys
// ==========================================================================

/**
 * Option key for the API Host URL.
 */
define('WOOREC_OPT_API_HOST', 'woorec_api_host');

/**
 * Option key for the API Access Token/Key.
 */
define('WOOREC_OPT_API_KEY', 'woorec_api_token');

/**
 * Option key for the user's subscription level (e.g., 'Free', 'Pro').
 */
define('WOOREC_OPT_USER_LEVEL', 'woorec_user_level');

/**
 * Option key for the user's subscription TTL (Time To Live / Expiry Timestamp).
 */
define('WOOREC_OPT_USER_TTL', 'woorec_user_ttl');

/**
 * Option key for storing general service status (e.g., 'online', 'error').
 */
define('WOOREC_SERVICE_STATUS_KEY', 'woorec_service_status');


// ==========================================================================
// 2. API Configuration & Endpoints
// ==========================================================================

/**
 * Endpoint for tracking user events (views, clicks, purchases).
 */
define('WOOREC_API_PATH_TRACE', '/trace');

/**
 * Endpoint for incremental data synchronization.
 */
define('WOOREC_API_PATH_INC_SYNC', '/inc');

/**
 * Endpoint for real-time recommendations (Pro tier).
 */
define('WOOREC_API_PATH_REC', '/rec');

/**
 * Endpoint for fetching Item-to-Item offline recommendations (Standard tier).
 */
define('WOOREC_API_PATH_I2I', '/i2i');

/**
 * Endpoint for fetching user license status (Level & TTL).
 */
define('WOOREC_API_PATH_STATUS', '/status');

/**
 * Maximum number of retries for high-availability requests.
 */
define('WOOREC_HAP_MAX_RETRY_NUM', 8);


// ==========================================================================
// 3. Database Meta Keys
// ==========================================================================

/**
 * Post Meta key used to store the list of recommended product IDs locally.
 */
define('WOOREC_META_I2I', '_woorec_i2i_ids');
define('WOOREC_META_RELATED', '_woorec_related_ids');
define('WOOREC_META_UPSELL', '_woorec_upsell_ids');
define('WOOREC_META_CROSSSELL', '_woorec_crosssell_ids');


// ==========================================================================
// 4. Scene Definitions
// ==========================================================================

/**
 * Scene identifier for "Related Products".
 */
define('WOOREC_SCENE_RELATED', 'woorec_scene_related');

/**
 * Scene identifier for "Upsells".
 */
define('WOOREC_SCENE_UPSELL', 'woorec_scene_upsell');

/**
 * Scene identifier for "Cross-sells" (Cart).
 */
define('WOOREC_SCENE_CROSSSELL', 'woorec_scene_crosssell');

/**
 * Scene identifier for "Category/Shop List" re-ranking.
 */
define('WOOREC_SCENE_LIST', 'woorec_scene_list');


// ==========================================================================
// 5. Data Synchronization Settings
// ==========================================================================

/**
 * Option key storing the timestamp of the last successful sync.
 */
define('WOOREC_OPT_LAST_SYNC_TIME', 'woorec_last_sync_timestamp');

/**
 * Number of products to process in a single batch.
 */
define('WOOREC_SYNC_BATCH_SIZE', 50);

/**
 * Maximum execution time (in seconds) allowed for a cron job step.
 */
define('WOOREC_CRON_TIME_LIMIT', 20);

/**
 * Time buffer (in seconds) to overlap sync windows to prevent data loss.
 * 300 seconds = 5 minutes.
 */
define('WOOREC_SYNC_BUFFER', 300);
